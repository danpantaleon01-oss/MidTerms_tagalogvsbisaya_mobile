// Tagalog vs Bisaya - Snake (PWA edition)
//
// Rewritten from the original pygame desktop game. Differences, and why:
// - Canvas/JS instead of pygame: runs in any browser, installable as a PWA,
//   and can be wrapped into a real downloadable .apk afterward (see README).
// - Controls: on-screen D-pad + swipe, since there's no keyboard on a phone.
// - Grid size is computed from the canvas's actual rendered size, so it
//   adapts to any screen instead of a fixed 800x600.
// - Scores are saved with localStorage instead of a scores.json file -
//   the correct, standard way a static, no-backend web app persists data
//   per-device/per-browser.
// - 2-player mode removed: it depended on two people sharing one keyboard
//   (arrows vs WASD), which has no equivalent on a single phone screen.

const COLS = 20;
const BASE_STEP_MS = 100;      // ms per move at the start
const MIN_STEP_MS = 50;        // fastest allowed
const SPEEDUP_PER_10_SCORE = 4; // ms faster per 10 points

const el = (id) => document.getElementById(id);

const screens = {
  menu: el('menu-screen'),
  name: el('name-screen'),
  game: el('game-screen'),
  gameover: el('gameover-screen'),
  leaderboard: el('leaderboard-screen'),
};

function showScreen(name) {
  Object.values(screens).forEach((s) => s.classList.add('hidden'));
  screens[name].classList.remove('hidden');
}

// ---------------------------------------------------------------------
// Sound
// ---------------------------------------------------------------------
const sounds = {
  eat: el('snd-eat'),
  death: el('snd-death'),
  win: el('snd-win'),
  music: el('snd-music'),
};
sounds.music.volume = 0.35;
Object.values(sounds).forEach((a) => { if (a !== sounds.music) a.volume = 0.5; });

function playSound(name) {
  const a = sounds[name];
  if (!a) return;
  a.currentTime = 0;
  a.play().catch(() => {}); // ignore autoplay-block errors
}

function startMusic() { sounds.music.play().catch(() => {}); }
function stopMusic() { sounds.music.pause(); sounds.music.currentTime = 0; }

// ---------------------------------------------------------------------
// Scores (localStorage)
// ---------------------------------------------------------------------
const SCORES_KEY = 'tagbis_scores';

function loadScores() {
  try {
    const data = JSON.parse(localStorage.getItem(SCORES_KEY));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function addScore(name, score) {
  const scores = loadScores();
  scores.push({ name: (name || 'Player').slice(0, 12), score });
  scores.sort((a, b) => b.score - a.score);
  const top10 = scores.slice(0, 10);
  localStorage.setItem(SCORES_KEY, JSON.stringify(top10));
  return top10;
}

// ---------------------------------------------------------------------
// Sprite images
// ---------------------------------------------------------------------
const sprites = {};
['head', 'body', 'tail', 'corner'].forEach((n) => {
  const img = new Image();
  img.src = `assets/p1/${n}.png`;
  sprites[n] = img;
});
const foodSprite = new Image();
foodSprite.src = 'assets/food/food.png';

// ---------------------------------------------------------------------
// Game state
// ---------------------------------------------------------------------
const canvas = el('game-canvas');
const ctx = canvas.getContext('2d');

let state = null; // set in startGame()

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.floor(rect.width);
  canvas.height = Math.floor(rect.height);
  if (state) {
    state.cell = canvas.width / COLS;
    state.rows = Math.max(10, Math.floor(canvas.height / state.cell));
    draw();
  }
}
window.addEventListener('resize', resizeCanvas);

function randomFood(snake, cols, rows) {
  const free = [];
  for (let x = 0; x < cols; x++) {
    for (let y = 0; y < rows; y++) {
      if (!snake.some(([sx, sy]) => sx === x && sy === y)) free.push([x, y]);
    }
  }
  if (free.length === 0) return null;
  return free[Math.floor(Math.random() * free.length)];
}

function startGame() {
  const cell = canvas.width / COLS;
  const rows = Math.max(10, Math.floor(canvas.height / cell));
  const startCol = Math.floor(COLS / 4);
  const startRow = Math.floor(rows / 2);

  state = {
    cell,
    rows,
    snake: [
      [startCol, startRow],
      [startCol - 1, startRow],
      [startCol - 2, startRow],
    ],
    direction: [1, 0],
    nextDirection: [1, 0],
    score: 0,
    stepMs: BASE_STEP_MS,
    timer: null,
  };
  state.food = randomFood(state.snake, COLS, state.rows);
  updateScoreLabel();
  scheduleTick();
  draw();
}

function scheduleTick() {
  if (state.timer) clearInterval(state.timer);
  state.timer = setInterval(tick, state.stepMs);
}

function stopGame() {
  if (state && state.timer) clearInterval(state.timer);
}

function setDirection(dx, dy) {
  if (!state) return;
  const [cdx, cdy] = state.direction;
  if (dx === -cdx && dy === -cdy) return; // no 180-degree reversals
  state.nextDirection = [dx, dy];
}

function updateScoreLabel() {
  el('score-label').textContent = `Score: ${state.score}`;
}

function tick() {
  state.direction = state.nextDirection;
  const [hx, hy] = state.snake[0];
  const [dx, dy] = state.direction;
  const nx = hx + dx;
  const ny = hy + dy;

  const hitWall = nx < 0 || nx >= COLS || ny < 0 || ny >= state.rows;
  const willEat = state.food && nx === state.food[0] && ny === state.food[1];
  const bodyToCheck = willEat ? state.snake : state.snake.slice(0, -1);
  const hitSelf = bodyToCheck.some(([sx, sy]) => sx === nx && sy === ny);

  if (hitWall || hitSelf) {
    playSound('death');
    stopGame();
    endGame();
    return;
  }

  state.snake.unshift([nx, ny]);
  if (willEat) {
    playSound('eat');
    state.score += 10;
    state.food = randomFood(state.snake, COLS, state.rows);
    if (!state.food) {
      playSound('win');
      stopGame();
      endGame();
      return;
    }
    state.stepMs = Math.max(MIN_STEP_MS, BASE_STEP_MS - Math.floor(state.score / 10) * SPEEDUP_PER_10_SCORE);
    scheduleTick();
    updateScoreLabel();
  } else {
    state.snake.pop();
  }
  draw();
}

function draw() {
  if (!state) return;
  ctx.fillStyle = '#0b0b0e';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  if (state.food) {
    const [fx, fy] = state.food;
    drawSprite(foodSprite, fx, fy);
  }

  const n = state.snake.length;
  state.snake.forEach(([cx, cy], i) => {
    const img = i === 0 ? sprites.head : i === n - 1 ? sprites.tail : sprites.body;
    drawSprite(img, cx, cy);
  });
}

function drawSprite(img, cx, cy) {
  const size = state.cell;
  if (img.complete && img.naturalWidth > 0) {
    ctx.drawImage(img, cx * size, cy * size, size, size);
  } else {
    ctx.fillStyle = '#5bd68a';
    ctx.fillRect(cx * size + 1, cy * size + 1, size - 2, size - 2);
  }
}

function endGame() {
  const name = currentPlayerName || 'Player';
  addScore(name, state.score);
  el('final-score').textContent = `${name}: ${state.score}`;
  showScreen('gameover');
}

// ---------------------------------------------------------------------
// Touch controls: swipe anywhere on the canvas
// ---------------------------------------------------------------------
let touchStart = null;
canvas.addEventListener('touchstart', (e) => {
  const t = e.changedTouches[0];
  touchStart = { x: t.clientX, y: t.clientY };
}, { passive: true });

canvas.addEventListener('touchend', (e) => {
  if (!touchStart) return;
  const t = e.changedTouches[0];
  const dx = t.clientX - touchStart.x;
  const dy = t.clientY - touchStart.y;
  if (Math.abs(dx) > 24 || Math.abs(dy) > 24) {
    if (Math.abs(dx) > Math.abs(dy)) setDirection(dx > 0 ? 1 : -1, 0);
    else setDirection(0, dy > 0 ? 1 : -1);
  }
  touchStart = null;
}, { passive: true });

// D-pad buttons (also work with mouse, for desktop-browser testing)
el('btn-up').addEventListener('click', () => setDirection(0, -1));
el('btn-down').addEventListener('click', () => setDirection(0, 1));
el('btn-left').addEventListener('click', () => setDirection(-1, 0));
el('btn-right').addEventListener('click', () => setDirection(1, 0));

// Arrow keys too, so this is also fully playable while testing on desktop
window.addEventListener('keydown', (e) => {
  if (screens.game.classList.contains('hidden')) return;
  if (e.key === 'ArrowUp') setDirection(0, -1);
  else if (e.key === 'ArrowDown') setDirection(0, 1);
  else if (e.key === 'ArrowLeft') setDirection(-1, 0);
  else if (e.key === 'ArrowRight') setDirection(1, 0);
});

// ---------------------------------------------------------------------
// Screen navigation
// ---------------------------------------------------------------------
let currentPlayerName = 'Player';

el('play-btn').addEventListener('click', () => {
  stopMusic();
  showScreen('name');
});

el('leaderboard-btn').addEventListener('click', () => {
  renderLeaderboard();
  showScreen('leaderboard');
});

el('start-btn').addEventListener('click', () => {
  currentPlayerName = el('name-input').value.trim() || 'Player';
  showScreen('game');
  resizeCanvas();
  startGame();
});

el('again-btn').addEventListener('click', () => {
  showScreen('game');
  resizeCanvas();
  startGame();
});

el('menu-btn').addEventListener('click', () => {
  showScreen('menu');
  startMusic();
});

el('back-btn').addEventListener('click', () => {
  showScreen('menu');
  startMusic();
});

function renderLeaderboard() {
  const list = el('score-list');
  list.innerHTML = '';
  const scores = loadScores();
  if (scores.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'No scores yet.';
    list.appendChild(li);
    return;
  }
  scores.forEach((s) => {
    const li = document.createElement('li');
    li.innerHTML = `<span>${s.name}</span><span>${s.score}</span>`;
    list.appendChild(li);
  });
}

// ---------------------------------------------------------------------
// PWA: register the service worker for offline play
// ---------------------------------------------------------------------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(() => {});
  });
}

// Start on the menu
showScreen('menu');
startMusic();
