# Tagalog vs Bisaya - PWA Edition

A browser-based rewrite of the game: plain HTML5 Canvas + JavaScript, no
build step, no framework. It installs to a phone's home screen like an
app (PWA), and can be wrapped into a real downloadable `.apk` afterward.

## What changed from the earlier versions

- **No Python at all for this version** - pure HTML/CSS/JS, since the
  target is "runs in a browser, installable as a PWA, wrappable as an APK."
- **Controls:** on-screen D-pad + swipe-anywhere-on-canvas, same as the
  Kivy version, re-implemented in JS. Arrow keys also work, for testing on
  a laptop before trying it on a phone.
- **Screen size:** canvas resizes to fill the device's actual screen.
- **Save data:** `localStorage` instead of a JSON file - the correct,
  standard way a static, no-backend web app persists data per device.
- **2-player mode:** still removed, same reasoning as before (no shared-
  keyboard equivalent on one phone).
- **Offline play:** `service-worker.js` caches every asset on first load,
  so once installed, it works with no internet connection at all.

## Step 1 - Test it locally, right now, no deployment needed

Browsers block service workers and some PWA features on plain
`file://` pages, so you need a tiny local server (not a real deployment,
just for testing):

```bash
cd tagalog-vs-bisaya-pwa      # this folder
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser. Resize the window, try
the arrow keys, try the on-screen D-pad with your mouse. Open it on your
phone too, if your phone and computer are on the same Wi-Fi network, by
visiting `http://<your-computer's-local-IP>:8000`.

## Step 2 - Deploy it to a real HTTPS URL (required for PWA install + APK)

A PWA's "Install" prompt and the APK-wrapping tools both require the site
to actually be live on the internet over HTTPS - `localhost` testing
isn't enough for those two specific features. Easiest free options:

**GitHub Pages** (if this is already a GitHub repo):
1. Push this folder's contents to your repo (root, or a `/docs` folder).
2. Repo Settings -> Pages -> set the source branch/folder.
3. Your site is live at `https://<username>.github.io/<repo>/`.

**Netlify / Vercel** (drag-and-drop, no git needed):
1. Go to netlify.com (or vercel.com) -> sign up free.
2. Drag this whole folder onto their "deploy" page.
3. You get a live `https://...` URL in under a minute.

## Step 3 - Confirm it installs as a PWA

Visit your live URL on an Android phone in Chrome. You should see a
"Add to Home Screen" / "Install app" prompt (or find it in Chrome's
3-dot menu -> "Install app"). Installing it puts an icon on the home
screen that opens full-screen, no browser bar - a real installed-feeling
app, with zero app-store or APK step needed at all for this part.

## Step 4 - Generate a downloadable .apk from the live PWA

This is the part that gets you an actual `.apk` file people can download
and sideload (outside any app store), using **PWABuilder** (free,
Microsoft-maintained, no install needed):

1. Go to **pwabuilder.com**.
2. Paste in your live HTTPS URL from Step 2 and click "Start".
3. It scans your manifest/service worker and shows a readiness report -
   fix anything it flags (this project's manifest/service worker are
   already set up correctly, so it should score well out of the box).
4. Click the **Android** package option -> "Generate Package".
5. Download the resulting `.apk` (or `.aab` if you want Play Store
   submission instead) directly - that's the file you hand to people to
   install, same as the Windows `.exe` before.

(Technical note, if you're curious: PWABuilder builds this using
**Trusted Web Activity (TWA)** - a thin, official Android wrapper that
just points at your live PWA. It's the same technique Google itself
recommends for shipping a PWA as a real Android app.)

## A few things worth knowing

- Because the APK is a thin wrapper pointing at your live site, **the
  site needs to stay hosted** at that URL for the app to keep working
  after install (GitHub Pages/Netlify free tiers are fine for this
  long-term, not just for testing).
- Audio autoplay is blocked by browsers until the user interacts with
  the page at least once - this is why the menu screen's background
  music only starts after `startMusic()` is called from a button click,
  not automatically on page load.
- Icons are already generated at 192x192 and 512x512 in `icons/`, the
  two sizes a PWA manifest needs.
