const CACHE_NAME = 'tagbis-snake-v1';
const ASSETS = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './assets/p1/head.png',
  './assets/p1/body.png',
  './assets/p1/tail.png',
  './assets/p1/corner.png',
  './assets/food/food.png',
  './assets/audio/tagalog_eat.mp3',
  './assets/audio/tagalog_death.mp3',
  './assets/audio/tagalog_win.mp3',
  './assets/audio/bg_music_lobby.mp3',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
